// Follow steps from the walkthrough guide to create HomeController
