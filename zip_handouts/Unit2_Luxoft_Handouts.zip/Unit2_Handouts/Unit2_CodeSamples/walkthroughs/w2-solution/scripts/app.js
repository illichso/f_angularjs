(function () {
  'use strict';

  angular.module('auction', []);
}());

